# Hudson Bay Terraform Code for "dev-aks-cluster203" Kubernetes Cluster. 
## This repository folder **terraform203** holds the IaC for kubernetes cluster "dev-aks-cluster203" placed under DevOps subscription.

### Terraform files list in the current folder holds the kubernetes cluster.

1. [Locals](./0-locals.tf)
2. [Provider](./1-provider.tf)
3. [Resource Group](./2-resource-group.tf)
4. [Virtual Network](./3-vnet.tf)
5. [Subnets](./4-subnets.tf)
6. [Azure Kubernetes Cluster](./5-aks.tf)
7. [Spot Node Pool](./6-spot-node-groups.tf)s
8. [Worker Node Pool](./7-worker-node-groups.tf)
9. [Backend](./backend.tf)
10. [Variables](./variables.tf)

## Usage in Terraform

Please view each file for more details on the implementation.

## Authors

Module is maintained by **Venkatesh J from ThoughtFocus**

## Copyright

@Hudson Bay Capital